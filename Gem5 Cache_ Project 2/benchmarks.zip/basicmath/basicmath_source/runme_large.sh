#!/bin/sh
basicmath_large > output_large.txt
