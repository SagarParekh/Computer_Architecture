#!/bin/sh
qsort_small input_small.dat > output_small.txt
