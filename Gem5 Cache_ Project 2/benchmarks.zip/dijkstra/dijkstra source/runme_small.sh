#!/bin/sh
dijkstra_small input.dat > output_small.dat
